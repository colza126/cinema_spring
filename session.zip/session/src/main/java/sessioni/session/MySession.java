package sessioni.session;

public class MySession {
    
    private int idUtente;

    public MySession(int idUtente) {
        this.idUtente = idUtente;
    }

    public MySession() {
        this.idUtente = 0;
    }

    
}
