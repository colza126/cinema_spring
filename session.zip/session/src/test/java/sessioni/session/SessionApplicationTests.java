package sessioni.session;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SessionApplicationTests {

	@Test
	void contextLoads() {
	}

}
